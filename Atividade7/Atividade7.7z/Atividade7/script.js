function jokenpo() {
    let escolha = prompt("Escolha: pedra, papel ou tesoura").toLowerCase();


    if (["pedra", "papel", "tesoura"].includes(escolha)) {

        let rand = Math.random();
        let escolhapc;

        if (rand < 0.33) {
            escolhapc = "pedra";
        } else if (rand < 0.66) {
            escolhapc = "papel";
        } else {
            escolhapc = "tesoura";
        }

        alert("O computador escolheu " + escolhapc);

        if (escolha === escolhapc) {
            alert("Empate!");
        } else if (escolha === "pedra" && escolhapc === "papel") {
            alert("Papel cobre pedra, você perdeu.");
        } else if (escolha === "pedra" && escolhapc === "tesoura") {
            alert("Pedra quebra tesoura, você venceu!");
        } else if (escolha === "papel" && escolhapc === "pedra") {
            alert("Papel cobre pedra, você venceu!");
        } else if (escolha === "papel" && escolhapc === "tesoura") {
            alert("Tesoura corta papel, você perdeu.");
        } else if (escolha === "tesoura" && escolhapc === "papel") {
            alert("Tesoura corta papel, você venceu!");
        } else if (escolha === "tesoura" && escolhapc === "pedra") {
            alert("Pedra quebra tesoura, você perdeu.");
        }

    } else {
        alert("Escolha inválida! Tente novamente.");
        jokenpo();
    }
}

