function receba(){
    const totalParticipantes = 4;
    const respostas = [];

    for (let i = 0; i < totalParticipantes; i++){
        const idade = parseInt(prompt(`Participante ${i+1}:\nDigite a idade:`));
        const genero = prompt(`Participante ${i+1}:\nDigite o gênero (masculino/feminino):`);
        const opiniao = parseInt(prompt(`Participante ${i+1}:
        \nOpinião: \n4- ótimo\n3- bom\n2- regular\n1- péssimo`));

        respostas.push({idade, genero, opiniao});
    }

    let idadeTotal = 0;
    let maisVelho = 0;
    let maisNovo = Infinity;
    let qtdBomOtimo = 0;
    let qtdPessimo = 0;
    let qtdHomem = 0;
    let qtdMulher = 0;

    respostas.forEach(respostas =>{
        idadeTotal += respostas.idade;
        if(respostas.idade > maisVelho) maisVelho = respostas.idade;
        if(respostas.idade < maisNovo) maisNovo = respostas.idade;

        if(respostas.opiniao == 1) qtdPessimo++;
        if(respostas.opiniao == 3 || respostas.opiniao == 4) qtdBomOtimo++;

        if(respostas.genero == "masculino") qtdHomem++;
        if(respostas.genero == "feminino") qtdMulher++
    });

    const mediaIdade = idadeTotal/totalParticipantes;
    const porcentagem = (qtdBomOtimo / totalParticipantes) * 100;

    alert(`Resultados da pesquisa:
    Média da idade: ${mediaIdade}
    Idade da pessoa mais velha: ${maisVelho}
    Idade da pessoa mais nova: ${maisNovo}
    Quantidade de pessoas que acharam péssimo: ${qtdPessimo}
    Porcentagem de pessoas que acharam bom/ótimo: ${porcentagem}%
    Número de mulheres que responderam: ${qtdMulher}
    Número de homens que responderam: ${qtdHomem} `);

}