
    const inputTexto = document.getElementById("inputTexto");
    const radioMaiusculas = document.getElementById("maiusculas");
    const radioMinusculas = document.getElementById("minusculas");

    radioMaiusculas.addEventListener("change", () => {
      inputTexto.value = inputTexto.value.toUpperCase();
    });

    radioMinusculas.addEventListener("change", () => {
      inputTexto.value = inputTexto.value.toLowerCase();
    });