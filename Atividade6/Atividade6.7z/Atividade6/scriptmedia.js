
function receba(){


    var nome = prompt("digite o seu nome");
    var nota1 = prompt("digite a primeira nota");
    var nota2 = prompt("digite a segunda nota");
    var nota3 = prompt("digite a terceira nota");
    var nota4 = prompt("digite a quarta nota");

    var media = (parseFloat(nota1)+parseFloat(nota2)+parseFloat(nota3)+parseFloat(nota4) ) / 4 ;
    
    alert("a média é: " + media);
}