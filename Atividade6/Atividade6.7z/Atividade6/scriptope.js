function receba(){
    var rnum1 = prompt("DIGITE O PRIMEIRO NÚMERO");
    var rnum2 = prompt("DIGITE O SEGUNDO NÚMERO");

    var num1 = parseFloat(rnum1);
    var num2 = parseFloat(rnum2);

    alert(`A soma dos números é: ${num1+num2}
A subtração do primeiro pelo segundo é: ${num1-num2}
A multiplicação ds números resulta em: ${num1*num2}
A divisão do primeiro pelo segundo é: ${num1/num2}
O resto da divisão do primeiro pelo segundo é: ${num1%num2}`);
}