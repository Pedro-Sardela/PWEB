function maiornNumero(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

function ordemCrescente(num1, num2, num3) {
    return [num1, num2, num3].sort((a, b) => a - b);
}

function palindromo(str) {
    const maiuscula = str.toUpperCase();
    const invertida = maiuscula.split('').reverse().join('');
    return maiuscula === invertida;
}

function triangulo(a, b, c) {
    if (a + b > c && a + c > b && b + c > a) {
        if (a === b && b == c) {
            return 'Triângulo Equilátero';
        } else if (a === b || b === c || a === c) {
            return 'Triângulo Isósceles';
        } else {
            return 'Triângulo Escaleno';
        }

    } else {
        return 'Não forma um trângulo';
    }
}

function recebaMaiorNumero(){
    const num1 = parseFloat(prompt("Digite o primeiro número:"));
    const num2 = parseFloat(prompt("Digite o segundo número:"));
    const num3 = parseFloat(prompt("Digite o terceiro número:"));
    alert('Maior número: ' + maiornNumero(num1, num2, num3));
}

function recebaOrdemCrescente(){
    const num1 = parseFloat(prompt("Digite o primeiro número:"));
    const num2 = parseFloat(prompt("Digite o segundo número:"));
    const num3 = parseFloat(prompt("Digite o terceiro número:"));
    alert('Números em ordem crescente: ' + ordemCrescente(num1, num2, num3).join(', '));
}

function recebaPalindromo(){
    const str = prompt("Digite uma palavra");
    if(palindromo(str) == true) alert(str + ' é palíndromo');
    if(palindromo(str) == false) alert(str + ' não é palíndromo');

}

function recebaTriangulo() {
    const a = parseFloat(prompt("Digite o comprimento do lado A:"));
    const b = parseFloat(prompt("Digite o comprimento do lado B:"));
    const c = parseFloat(prompt("Digite o comprimento do lado C:"));
    alert(triangulo(a, b, c));
}