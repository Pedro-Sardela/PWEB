class Retangulo{
    constructor(x, y){
        this.x = x;
        this.y = y;
    }

    area()
    {
        return(this.x * this.y);
    }
}

function recebaRetangulo(){
    const retx = parseFloat(prompt("digite a base do retângulo: "));
    const rety = parseFloat(prompt("digite a altura do retângulo: "));


    var retangulo = new Retangulo(retx, rety);
    alert(`base = ${retangulo.x} altura = ${retangulo.y} área = ${retangulo.area()}`);
}

class Conta{
    constructor(nome, banco, numConta, saldo){
        this.nome = nome;
        this.banco = banco;
        this.numConta = numConta;
        this.saldo = saldo;
    }

    getNome(){
        return this.nome;
    }
    getBanco(){
        return this.banco;
    }
    getNumConta(){
        return this.numConta;
    }
    getSaldo(){
        return this.saldo;
    }

    setNome(n){
        this.nome = n;
    }
    setBanco(b){
        this.banco = b;
    }
    setNumConta(nc){
        this.numConta = nc;
    }
    setSaldo(s){
        this.saldo = s;
    }

}

class Corrente extends Conta{

    constructor(nome, banco, numConta, saldo, saldoEsp){
        super(nome, banco, numConta, saldo);
        this.saldoEsp = saldoEsp;

    }

    getSaldoEsp(){
        return this.saldoEsp;
    }


    setSaldoEsp(se){
        this.saldoEsp = se;
    }

}

class Poupanca extends Conta{
       
    constructor(nome, banco, numConta, saldo, juros, dataVencimento){
        super(nome, banco, numConta, saldo);
        this.juros = juros;
        this.dataVencimento = dataVencimento;
    }
    
    getJuros(){
        return this.juros;
    }
    getDataVencimento(){
        return this.dataVencimento;
    }
    
    setJuros(j){
        this.juros= j;
    }
    setDataVencimento(dv){
        this.dataVencimento = dv;
    }
}

function recebaConta(){
    const tipo = prompt("digite se a conta é CORRENTE ou POUPANÇA: ");
    const nome = prompt("digite seu nome: ");
    const banco = prompt("digite o banco: ")
    const saldo = prompt("digite o saldo: ");
    const min = 1;
    const max = 99;
    const numConta = Math.floor(Math.random() * (max - min + 1)) + min;

    if (tipo.toUpperCase() == "CORRENTE"){
        const saldoEsp = prompt("Digite o saldoEsp da conta: ");
        var ctCorrente = new Corrente(nome, banco, saldo, numConta, saldoEsp);

        alert(`nome = ${ctCorrente.getNome()} 
        banco = ${ctCorrente.getBanco()} 
        saldo = ${ctCorrente.getSaldo()}
        numConta = ${ctCorrente.getNumConta()}
        saldoEsp = ${ctCorrente.getSaldoEsp()}`);
    }
    else if (tipo.toUpperCase() == "POUPANÇA"){
        const juros = parseFloat(prompt("Digite ojuros de 0 a 100: ")) / 100;
        const dataVencimento = ("Digite a data de vencimento: ");
        var ctPoupanca = new Poupanca(nome, banco, numConta, saldo, juros, dataVencimento);

        alert(`nome = ${ctPoupanca.getNome()} 
        banco = ${ctPoupanca.getBanco()} 
        saldo = ${ctPoupanca.getSaldo()}
        numConta = ${ctPoupanca.getNumConta()}
        Juros = ${ctPoupanca.getJuros() * 100}%
        data vencimento = ${ctPoupanca.getDataVencimento()}`);
    }
    else{
        alert("erro!");
    }

    alert(`nome = ${ctCorrente.getNome()} 
        banco = ${ctCorrente.getBanco()} 
        saldo = ${ctCorrente.getSaldo()}
        numConta = ${ctCorrente.getNumConta()}
        saldoEsp = ${ctCorrente.getSaldoEsp()}`);
}
